
#ifndef ___terminal_marshal_MARSHAL_H__
#define ___terminal_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* BOOLEAN:STRING,INT,UINT (./terminal-marshal.list:1) */
G_GNUC_INTERNAL void _terminal_marshal_BOOLEAN__STRING_INT_UINT (GClosure     *closure,
                                                                 GValue       *return_value,
                                                                 guint         n_param_values,
                                                                 const GValue *param_values,
                                                                 gpointer      invocation_hint,
                                                                 gpointer      marshal_data);

G_END_DECLS

#endif /* ___terminal_marshal_MARSHAL_H__ */

