void skey_sevenbit(char *s);
void skey_lowcase(char *s);

