README_bindos.txt for version 7.3 of Vim: Vi IMproved.

See "README.txt" for general information about Vim.
See "README_dos.txt" for installation instructions for MS-DOS and MS-Windows.
These files are in the runtime archive (vim73rt.zip).


There are several binary distributions of Vim for the PC.  You would normally
pick only one of them, but it's also possible to install several.
These ones are available (the version number may differ):
	vim73d16.zip	16 bit DOS version
	vim73d32.zip	32 bit DOS version
	vim73w32.zip	Windows 95/98/NT/etc. console version
	gvim73.zip	Windows 95/98/NT/etc. GUI version
	gvim73ole.zip	Windows 95/98/NT/etc. GUI version with OLE
	gvim73_s.zip	Windows 3.1 GUI version

You MUST also get the runtime archive (vim73rt.zip).
The sources are also available (vim73src.zip).
